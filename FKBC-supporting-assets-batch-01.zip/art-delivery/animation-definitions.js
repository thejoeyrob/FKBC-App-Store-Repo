// No animation frames delivered in this batch. Do not register missing clips.
export const animationDefinitions = [];
