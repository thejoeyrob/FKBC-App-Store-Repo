// Generic loader only; not tested against the project.
export function loadSupportingArtwork(scene, manifest, base = 'art-delivery/') {
  for (const asset of manifest.assets) {
    scene.load.image(asset.key, base + asset.path);
  }
}
