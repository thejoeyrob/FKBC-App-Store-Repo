// Browser-side texture dimensions check; alpha/registration require offline QA.
export function validateLoadedAssets(scene, manifest) {
 return manifest.assets.map(a => {
  if (!scene.textures.exists(a.key)) return {key:a.key, ok:false, reason:'missing texture'};
  const image = scene.textures.get(a.key).getSourceImage();
  return {key:a.key, ok:image.width===a.width && image.height===a.height};
 });
}
