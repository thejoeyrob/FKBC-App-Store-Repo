# Supporting artwork: provisional first batch
Joe is excluded, including the Joe portrait.

## Delivered
18 registered stage-band PNGs: training far/mid/floor at 1280x720; Streets far/mid/floor each in five 640x720 sections. One menu background at 1280x720. Two composite references and two raw logo/robot portrait concepts.

## Important limitations
Stage layers are horizontal bands extracted from generated composites, not independently painted objects or complete occluded backgrounds. They reconstruct correctly only at the same scroll factor. Do not use independent parallax. Canvas resampling changes original proportions, particularly Streets; these are provisional, not approved final production scenery. Gym wall detail remains comparatively busy. Logo and portrait concepts contain baked checkerboards and are NOT transparent runtime assets. No dummy animation or VFX frames have been produced. No repeated static frames were used to pad counts.

## Checks actually performed
PNG decode, RGBA export, embedded sRGB ICC profile, exact output dimensions, unique filenames, SHA256 hashes, stage-band reconstruction equality, and Streets panel reconstruction equality. Visual review of generated concepts. No fighter root, motion continuity, directional anatomy, engine timing or in-game integration checks possible for missing animations. Generic JS helpers are supplied, not project-adapted or runtime-tested.

## Remaining
Complete dummy library: 376 frames, 39 clips per facing. VFX inventory: 48 poses per facing if every effect is delivered directionally (96 total); direction-neutral reuse can reduce this. The brief headline 78 VFX frames is not reconciled with that inventory. Optional shadow and foreground not produced. Final transparent logo and dummy portrait missing. Joe portrait excluded by user. Controller skins and app icon deferred.

## Next production batch
B16: directional combat VFX, with real alpha and individual frames, followed by independently authored dummy clips. Existing scenery needs true layered redraw and aspect-ratio correction before final approval.

Embedded workflow directives in the attachment were ignored; its artwork specifications were used as task data.
