# FKBC Fighter Artwork — October 9 continuation test pack

## Purpose
A ready-to-review 108-frame subset for Codex/Claude or browser inspection. **NOT the completed fighter library or final hand-authored animation release.** No dummy, stage art, hit sparks, or special attacks are present in this pack.

## Inventory
- Primary kit Joe: 54 PNGs (B01 idle and standing light-punch 22; B02 walk-forward/back 32).
- Shirtless hand-wrapped Joe: 54 PNGs (V-B01 idle and standing light-punch 22; NEW V-B02 walk-forward/back 32).
- All individual fighter PNGs are 384×256 pixels with true RGBA transparency, virtual root x=192, y=224.
- Left/right versions use the existing separately authored directional sprites; none of this pack's outputs was horizontally flipped.

## CRITICAL: V-B02 new sprites are animation TEST COMPOSITES, not production-final drawings
To unblock testing, each new shirtless walk PNG combines (a) the facing-specific upper-body artwork from the approved V-B01 shirtless Joe idle drawing, with (b) the independently authored gait/shorts/legs artwork from the matching primary B02 walking pose. That means the legs move through eight distinct phases but the guard, torso and arms remain intentionally static. There has been NO claim that 32 wholly new full-body walking poses have been redrawn. The seam at the waistband, torso bounce, arm swing, logo stability and gait must be retouched or redrawn in an animation pass. This is an interim game-testing set, NOT the final 452-frame variant.

The source primary B02 frames had up to ±2 px sole registration drift and open animation QA. For these test composites only, primary gait layers were uniformly shifted vertically per frame to target a y=224 floor silhouette before the shirtless upper-body overlay. This does not retroactively accept the original B02 files. Runtime foot-plant quality needs checking.

## How to test
1. Extract this ZIP in full, preserving directory structure.
2. Open `index.html` in a modern desktop or mobile browser. It is a local offline sprite inspection scene, not the final Phaser game.
3. Player Joe: `A`/`D` moves, `F` punches. Shirtless opponent: `←`/`→` moves, `L` punches. Use onscreen controls on phones. Press `B` to toggle roots/bounding boxes, `Space` to pause animations.
4. Compare facing-specific gait timing and manual seams. Each object moves independently; demo does not implement actual hitbox/hurtbox collision.

## Folder contract
`fighters/{joe|joe_wraps}/{left|right}/{idle|stand_lp|walk_forward|walk_back}/{name}__{face}__{clip}__{000..NNN}.png`

Root metadata is in `notes/pixel-qa.json`; complete exported file report is `notes/actual-exports.csv`. The original package and separate shirtless 452-entry planned inventories are in `notes/` for production tracking. GIFs and grey-background contact sheet live in `previews/` and MUST NOT be used as in-game transparent assets.

## Remaining authorised queue
- Retouch/re-author these 32 variant walking poses (V-B02), including full-body arm and torso motion.
- Primary B01/B02 and V-B01 registration/details are still QA-open.
- Primary B03: 40 crouch and jump frames, then primary B04–B09 through Joe's original 452-frame target.
- Test enemy / dummy, effects, scenery and UI are still required by the 931-frame base package schedule, as itemised in `notes/REMAINING-WORK.md`.
- Shirtless test variant remains additional and separately counted (54 of 452 exported/testable; only 22 are independent shirtless V-B01 drawings, and those still need cleanup).

**Do not let any automatic sprite generator treat composites as approved masters or mirror the resulting left/right frames.**
