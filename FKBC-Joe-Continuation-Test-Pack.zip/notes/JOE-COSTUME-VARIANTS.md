# Joe costume variants — production addendum

The primary Joe library retains its 43 clips, 226 poses per facing, 452 PNG target.
Kit variant: approved black/red short-sleeve FKBC shirt and shorts, boxing gloves,
bare legs/feet, left-arm tattoo and left-biceps red/white two-tassel armband.

joe_wraps is a separate shirtless test-opponent variant requested on 9 October.
Same identity, build, shorts, tattoo and armband. White cotton bandage hand wraps
replace gloves; bare chest/back and bare feet. No new chest/back tattoos invented.
Both reference stances have been independently drawn from the corresponding
approved direction master. No horizontal image flip was used.

The separate joe-wraps-completion-manifest.csv tracks matching 452-pose coverage
without counting costume alternates toward the primary Joe 452-frame target.
V-B01 now contains 6 idle +5 standing LP per facing =22 exported frames, with
registration/motion/detail cleanup outstanding (README-VB01.md). Its two idle000
frames promote the existing stance references; no duplicate poses fill the clips.
430 variant frames remain unmade. Next: V-B02 walks32, separately authored facings.
The original robot/dummy production plan remains pending; this test opponent is
an addition, not an unannounced replacement.

No separate shirtless reference illustration was resolved in the Library searches.
These designs use the approved Joe masters and the explicit costume instructions.
