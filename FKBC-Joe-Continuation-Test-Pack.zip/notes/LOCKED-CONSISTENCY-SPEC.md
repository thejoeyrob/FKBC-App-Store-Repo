# FKBC Joe — locked consistency specification v3 (bare legs/feet and tasselled armband)

Controlling source: START-HERE-production-prompt.md in the supplied full production
pack. Its full-library, independently authored both-facing requirements supersede
the older pilot-only and automatic-mirroring restrictions. Other named human
fighters remain outside scope.

## Identity and rendering
The punching reference controls polished illustrated arcade rendering only:
confident dark outlines, crisp warm painted/cel-shaded volumes. The original FKBC
reference controls Joe's face, textured swept brown hair with faded sides, close
beard, athletic muscular build and clothing. The model sheet is a secondary guide.
No pixel conversion and no adoption of the style-reference fighter's costume.

Joe is approximately 7 to 7.5 heads tall when upright. Preserve head size, shoulder
width, torso length, thigh/shin lengths and glove/guard sizes across clips. At
gameplay resolution the face, tattoo and fabric marks become deliberate simple
shapes, not arbitrary additional detail.

## Costume and anatomy
- Black fitted short-sleeve crew-neck shirt; red shoulder slashes and red/white
  lower-side print accents. A white/red club mark centred on the front chest.
- Black kickboxing shorts, above knee, red hems/outer panels. Front waistband
  patch reads FKBC; club graphic on anatomical left front thigh.
- Black closed boxing gloves, red cuffs/piping, small white FKBC cuff lettering.
- User revision: NO shin pads or instep pads. Bare lower legs and completely bare
  feet. No ankle guards, wraps, socks or shoes. Earlier references showing pads
  are superseded for this detail only.
- Red-and-white braided Muay Thai armband on anatomical LEFT upper arm, just
  below the short sleeve. Two hanging red/white cord tassels, ending near the
  elbow. Same attachment and length across frames; restrained secondary motion.
- Anatomical LEFT forearm/upper exposed arm carries the rose/floral tattoo;
  anatomical RIGHT arm is bare. Never swap these to expose the tattoo to camera.
- Back treatment: black rear shirt with matching shoulder/side accents, no extra
  back wordmark. This completes the unseen rear consistently with the model sheet.
- No belt, gi, hand wraps, trousers, hood or shoes.

The corresponding supplied palette CSV/GPL defines numeric colour targets.
Screen light is neutral upper-left for BOTH facings; no opposite-face light flip.

## Camera and facing
Fixed eye-level gameplay camera; restrained three-quarter side presentation,
based on the model-sheet fighting stance. No changing camera azimuth, zoom or
perspective between animation frames. Anatomical body turns for attacks are allowed.
Orthodox guard: anatomical LEFT hand and LEFT leg lead in both facing directions.
Standing LP is a left lead jab; the right glove protects the jaw.
RIGHT-facing view principally exposes the untattooed right-side arm, with the
tattooed left lead arm visible as permitted by pose. LEFT-facing view reveals
the opposite anatomy. It is reconstructed independently, never a flipped image.
Keep all visible lettering correctly oriented; tiny text may simplify at final size.

## Registration and export targets
Final PNG cell: 384 x 256, untrimmed, sRGB RGBA with genuine alpha.
Virtual root: (192,224) from top-left for every fighter frame and both facings.
Standing height: 126–132 px; standing body width around 54–64 px, extended limbs
may exceed this body-width reference. The root is the projected pelvis-ground
reference between planted feet, not necessarily an opaque foot pixel.

Generation working canvas target: 1536 x 1024, exactly four times the final cell.
The first right-facing master received ONE documented layout calibration because
the generator ignored the numeric placement guide. See master-calibration.json.
The left master also received one initial floor translation (no scaling), recorded
in left-master-calibration.json. All later poses must follow these calibrated
masters directly; do not normalize them
individually. Working root (768,896); standing silhouette height 504–528 px; final export uses
one shared full-canvas 25% reduction only. Never individually fit, crop, recenter,
stretch or change scale to disguise generator registration errors. If the generator
misses layout, record the failure or redraw. Final pixels and alpha must be checked.
Both feet stay planted for idle and this light jab. Knees, chest, shoulders and
guard articulate; no game-world translation is baked into the cell.
No floor shadow, background, VFX, guides, UI, watermark or non-costume text.

## Batch 01 pose intent
Both facings have the same six idle phases and five light-punch phases.
Idle 000 neutral guard; 001 inhale begins; 002 inhale crest; 003 exhale begins;
004 exhale settles; 005 return toward neutral. Feet unchanged; subtle 1–2 px
upper-body motion, no duplicated files used as different drawn poses.
Standing LP 000 anticipation (small shoulder load, no exaggerated windup);
001 extension; 002 full contact; 003 recovery/retraction; 004 resettle into guard.
Game combat timing controls playback. Preview timing is illustrative only.

## Superseded generation attempts
The first two idle calibration attempts used the old pads and are rejected.
Any bare-leg attempt made before the armband revision is also superseded.
They are not counted in the delivered animation inventory. The left-facing
attempt also failed the left-lead pose target. Both must be redrawn.

## Quality status policy
All numbers above are locked targets, not a certificate for unmade files.
Mark actual delivery, dimensions, alpha, colour profile, file uniqueness, and
sequence coverage separately from visual/anatomical/registration acceptance.
Record defects and any manual cleanup explicitly. No invented layered sources.
