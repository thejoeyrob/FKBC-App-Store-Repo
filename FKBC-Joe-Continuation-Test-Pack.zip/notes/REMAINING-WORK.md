# FKBC production status after V-B01 drawing/export delivery

Primary package:54 fighter PNGs exported (22 B01 delivered;32 B02 cleanup required).
877 original-package PNGs unmade;32 exported B02 frames still require acceptance cleanup.
Additional shirtless variant:22 animation PNGs exported, all requiring cleanup;
430 variant frames unmade, tracked separately. Entire package:
NOT complete. Optional shadow/foreground exports are excluded from required totals.
Every individual expected filename is in completion-manifest.csv.

| Batch | Scope, both facings for fighters | Required PNGs | Status |
|---|---|---:|---|
| B01 | Joe idle + standing LP | 22 | Delivered; QA notes apply |
| B02 | Joe walk forward + walk back | 32 | Drawn/exported; registration and motion cleanup |
| B03 | Joe crouch transitions/idle + jump phases/landing | 40 | Not started |
| B04 | Joe high/low guard + standing/crouching/air hits | 24 | Not started |
| B05 | Joe knockdown/down/getup/KO/victory | 40 | Not started |
| B06 | Joe remaining standing normals | 66 | Not started |
| B07 | Joe six crouching normals | 76 | Not started |
| B08 | Joe six airborne normals | 76 | Not started |
| B09 | Joe projectile/tornado/rising/sidekick body clips | 76 | Not started |
| B10 | Dummy model/palette, idle, walk/crouch locomotion | 60 | Not started |
| B11 | Dummy jump, landing, guards and hit reactions | 48 | Not started |
| B12 | Dummy knockdown/down/getup/KO/victory | 40 | Not started |
| B13 | Dummy six standing normals | 76 | Not started |
| B14 | Dummy six crouching normals | 76 | Not started |
| B15 | Dummy six airborne normals | 76 | Not started |
| B16 | Separate VFX, directional where specified | 78 | Not started |
| B17 | Training far/mid/floor registered layers | 3 | Not started |
| B18 | Streets three full layer masters +15 panels | 18 | Not started |
| B19 | Two portraits, logo, menu background | 4 | Not started |

Larger batches may be split at clip boundaries, retaining precise filename-level
status. The Dummy model sheet/palette and supporting documents are reference
deliverables in addition to the931 required animation/scenery/UI PNGs counted here.
No Jack, John, Justin, Paul, throws, supers, taunts, controller skins or app-store
marketing work is authorised in this production sequence.

VFX direction policy: projectile spawn/loop/impact, tornado and rising arcs receive
separately authored right/left versions. Radial hit/block sparks and vertical
landing dust are shared. Optional floor shadow is separate. No projectile baked
into the rising body animation. Dummy gets no Joe specials.

## Exact next continuation
Next drawing batch is **V-B02: shirtless Joe walk_forward000–007 and
walk_back000–007, RIGHT and LEFT**,32 PNGs. Use the facing-specific shirtless
masters, preserve the left tattoo/armband and never mirror. B02 and V-B01
registration/motion cleanup remains open in their respective README files.
Then resume primary B03 crouch/jump40. The original
full primary Joe452-frame target remains active; variant files have a separate
452-entry manifest and never inflate primary completion counts.

Before strict acceptance of B01, clean the extra1px at the top of right idle001/002
if the132px upper silhouette target is enforced exactly, and assess redraw shimmer
and timing in the live game. These minor QA exceptions are not hidden by resizing.
